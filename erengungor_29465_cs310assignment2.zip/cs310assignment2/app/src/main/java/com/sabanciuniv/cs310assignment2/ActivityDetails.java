package com.sabanciuniv.cs310assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ActivityDetails extends AppCompatActivity {

    ImageView imgDetails;
    TextView titleTxtDetails;
    TextView dateTxtDetails;
    TextView textTxtDetails;


    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {

            News news = (News)message.obj;

            titleTxtDetails.setText(news.getTitle());
            dateTxtDetails.setText(news.getDate().substring(0,10));
            textTxtDetails.setText(news.getText());

            NewsRepository repo = new NewsRepository();
            repo.downloadImage(((NewsApp)getApplication()).srv, imgHandler, news.getImage());

            return true;
        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            Bitmap img = (Bitmap) msg.obj;
            imgDetails.setImageBitmap(img);

            return true;
        }
    });

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        int id = getIntent().getIntExtra("id", 1);

        imgDetails = findViewById(R.id.imgDetails);
        titleTxtDetails = findViewById(R.id.titleDetails);
        dateTxtDetails = findViewById(R.id.dateDetails);
        textTxtDetails = findViewById(R.id.textDetails);

        NewsRepository repo = new NewsRepository();
        repo.getNewsById(((NewsApp)getApplication()).srv, dataHandler, id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {

        int id = item.getItemId();
        int newsid = getIntent().getIntExtra("id", 1);

        if(id == android.R.id.home)
        {
            finish();
        }
        else if (id == R.id.commentButton)
        {
            Intent i = new Intent(ActivityDetails.this, CommentActivity.class);
            i.putExtra("id", newsid);
            startActivity(i);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
