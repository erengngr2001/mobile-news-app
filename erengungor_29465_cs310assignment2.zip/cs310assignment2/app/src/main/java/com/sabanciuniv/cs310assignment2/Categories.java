package com.sabanciuniv.cs310assignment2;

public class Categories {

    private int id;
    private String name;

    public Categories() {
    }

    public Categories(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return name;
    }

    public void setCategory(String category) {
        this.name = name;
    }
}
