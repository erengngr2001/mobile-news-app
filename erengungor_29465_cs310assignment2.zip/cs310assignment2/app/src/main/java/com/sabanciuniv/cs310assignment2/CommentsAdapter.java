package com.sabanciuniv.cs310assignment2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>{

    private Context ctx;
    private List<Comments> data;

    public CommentsAdapter(Context ctx, List<Comments> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public CommentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View root = LayoutInflater.from(ctx).inflate(R.layout.comments_row_layout, parent, false);

        CommentsViewHolder holder = new CommentsViewHolder(root);
        holder.setIsRecyclable(false);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CommentsViewHolder holder, int position) {

        holder.userName.setText(data.get(holder.getAdapterPosition()).getName());
        holder.userComment.setText(data.get(holder.getAdapterPosition()).getText());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    class CommentsViewHolder extends RecyclerView.ViewHolder
    {
        TextView userName;
        TextView userComment;
        //ImageView userIcon;
        ConstraintLayout row;

        public CommentsViewHolder(@NonNull View itemView) {
            super(itemView);

            userName = itemView.findViewById(R.id.userNameList);
            userComment = itemView.findViewById(R.id.commentList);
            //userIcon = itemView.findViewById(R.id.defaultUserIcon);
            row = itemView.findViewById(R.id.comments_row);
        }
    }



















}
