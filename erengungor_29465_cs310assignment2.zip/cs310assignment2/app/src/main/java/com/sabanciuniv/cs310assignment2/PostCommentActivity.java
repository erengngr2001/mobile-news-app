package com.sabanciuniv.cs310assignment2;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;

public class PostCommentActivity extends AppCompatActivity {

    EditText username;
    EditText usercomment;
    Button postCommentBtn;
    TextView errorMsg;

    Handler postingHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {

            int control = (int)message.obj;
            if (1 == control)
            {
                errorMsg.setVisibility(View.INVISIBLE);
                Toast.makeText(getApplicationContext(), "Thanks for commenting! :)", Toast.LENGTH_SHORT).show();
                finish();
            }
            else {
                errorMsg.setVisibility(View.VISIBLE);
            }
            return true;

        }
    });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment_posting_layout);
        setTitle("Post Comment");

        username = findViewById(R.id.postingUserNameText);
        usercomment = findViewById(R.id.postingUserCommentText);
        postCommentBtn = findViewById(R.id.postCommentButton);
        errorMsg = findViewById(R.id.successMsgText);
        errorMsg.setVisibility(View.INVISIBLE);
        username.setVisibility(View.VISIBLE);
        usercomment.setVisibility(View.VISIBLE);
        postCommentBtn.setVisibility(View.VISIBLE);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        postCommentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = usercomment.getText().toString();
                String name = username.getText().toString();
                ExecutorService srv = ((NewsApp)getApplication()).srv;
                CommentsRepository repo = new CommentsRepository();

                int news_id = getIntent().getIntExtra("id", 1);

                repo.saveComment(srv, postingHandler, news_id, usercomment, username);
            }
        });

    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == android.R.id.home)
        {
            finish();
        }

        return true;
    }

}
