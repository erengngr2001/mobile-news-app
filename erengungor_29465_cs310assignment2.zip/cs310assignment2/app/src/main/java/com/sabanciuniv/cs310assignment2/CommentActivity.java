package com.sabanciuniv.cs310assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.List;

public class CommentActivity extends AppCompatActivity {

    RecyclerView recView;

    Handler commentHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {

            List<Comments> data = (List<Comments>)message.obj;
            CommentsAdapter adp = new CommentsAdapter(CommentActivity.this, data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);

            return true;
        }
    });

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showcomments_activity);

        int id = getIntent().getIntExtra("id", 1);

        recView = findViewById(R.id.commentRecView);
        recView.setLayoutManager(new LinearLayoutManager(this));
        recView.setVisibility(View.INVISIBLE);
        setTitle("Comments");

        CommentsRepository repo = new CommentsRepository();
        repo.getCommentsByNewsId(((NewsApp)getApplication()).srv, commentHandler, id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        setContentView(R.layout.showcomments_activity);

        int id = getIntent().getIntExtra("id", 1);

        recView = findViewById(R.id.commentRecView);
        recView.setLayoutManager(new LinearLayoutManager(this));
        recView.setVisibility(View.INVISIBLE);
        setTitle("Comments");

        CommentsRepository repo = new CommentsRepository();
        repo.getCommentsByNewsId(((NewsApp)getApplication()).srv, commentHandler, id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_postcommentbutton, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        int newsid = getIntent().getIntExtra("id", 1);

        if(id == android.R.id.home)
        {
            finish();
        }
        else if(id == R.id.postCommentMenuIcon)
        {
            Intent i = new Intent(CommentActivity.this, PostCommentActivity.class);
            i.putExtra("id", newsid);
            startActivity(i);

            return true;
        }

        return true;
    }

}
